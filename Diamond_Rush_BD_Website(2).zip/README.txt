Diamond Rush BD
===============
এটি একটি মোবাইল-ফ্রেন্ডলি ডেমো Free Fire Top-Up ওয়েবসাইট।

ব্যবহার:
1. ZIP ফাইলটি Extract করুন।
2. index.html ফাইলটি Chrome দিয়ে খুলুন।
3. অনলাইনে দিতে চাইলে GitHub Pages/অন্য hosting-এ index.html আপলোড করুন।

কনট্যাক্ট:
Nagad: 01877786033
WhatsApp: 01829095129
Telegram: @rifat00r99

নোট: এটি ডেমো। বাস্তব অটো পেমেন্ট ও বৈধ top-up delivery চালু করতে অনুমোদিত payment gateway এবং বৈধ supplier/API প্রয়োজন।
